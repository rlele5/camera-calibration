% main_calibrate - Calibrate pointer
% Run "run_main" with image: "p0_6_m10_calibrate4.JPG", and then run this file.

% Probe tip global coordinates
probe_tip_global_coord = [0 6 -10 1]';

probe_tip_cam_coord_tmp = E * probe_tip_global_coord







