function vector_magnitude = v_mag(coord)

    vector_magnitude = sqrt(coord(1)^2 + coord(2)^2);

end